<?php
define('WCMp_PLUGIN_TOKEN', 'wcmp');

define('WCMp_TEXT_DOMAIN', 'dc-woocommerce-multi-vendor');

define('WCMp_PLUGIN_VERSION', '3.4.7');

define('WCMP_SCRIPT_DEBUG', false);
