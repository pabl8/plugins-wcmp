<?php

namespace Stripe\Error;

class Authentication extends Base
{
}
